# IT咨讯
-----
## 配置，请前往天行数据申请api:
https://www.tianapi.com/apiview/20

(api每日免费100次调用,插件每日只请求一次，当`news`目录中存在当天的新闻时，直接从本地文件发送，不调用api)

## 在`.env.dev`中添加
CUSTOM_CONFIG_IT=[你申请api的key]

## 指令

`it新闻`
`It新闻`
`IT新闻`
`it咨讯`
`It咨讯`
`IT咨讯`
`IT`
`it`
`It`

每日只请求一次，当`news`目录中存在当天的新闻时，直接从本地文件发送，不请求api

**给个star吧~**

## 截图

![](https://cdn.jsdelivr.net/gh/yzyyz1387/blogimages/img/nonebot_p_it.png)

![](https://cdn.jsdelivr.net/gh/yzyyz1387/blogimages/img/none_p_it2.png)



